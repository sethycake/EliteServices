import time
from time import sleep 


print('''

             ▄▄▄ .▄▄▌  ▪  ▄▄▄▄▄▄▄▄ .    .▄▄ · ▄▄▄ .▄▄▄   ▌ ▐·▪   ▄▄· ▄▄▄ .
             ▀▄.▀·██•  ██ •██  ▀▄.▀·    ▐█ ▀. ▀▄.▀·▀▄ █·▪█·█▌██ ▐█ ▌▪▀▄.▀·
             ▐▀▀▪▄██▪  ▐█· ▐█.▪▐▀▀▪▄    ▄▀▀▀█▄▐▀▀▪▄▐▀▀▄ ▐█▐█•▐█·██ ▄▄▐▀▀▪▄
             ▐█▄▄▌▐█▌▐▌▐█▌ ▐█▌·▐█▄▄▌    ▐█▄▪▐█▐█▄▄▌▐█•█▌ ███ ▐█▌▐███▌▐█▄▄▌
              ▀▀▀ .▀▀▀ ▀▀▀ ▀▀▀  ▀▀▀      ▀▀▀▀  ▀▀▀ .▀  ▀. ▀  ▀▀▀·▀▀▀  ▀▀▀ 

»-----------------------------------------------•------------------------------------------------------------«

            1 Ip Port Scanning             2 Ip Stresser              3 Ip Info                     

»-----------------------------------------------•------------------------------------------------------------«
''')

choice = input('>>>')

if choice == '1':
    print('https://www.adminsub.net')
    time.sleep(0.3)
    print('https://speedguide.net')
    time.sleep(0.3)
    print('https://iana.org')
    time.sleep(0.3)
    print('https://portforward.com')
    time.sleep(600)

elif choice == '2':
    print('zdstresser')
    print('https://zdstresser.zone/')
    time.sleep(0.3)
    print('J0k3r')
    print('https://joker.sh/')
    time.sleep(0.3)
    print('stresser.tech')
    print('https://stresser.tech/login')
    time.sleep(0.3)
    print('Maostresser')
    print('https://mao-stress.tech/')
    time.sleep(0.3)
    print('Stresser Website')
    print('https://stresser.website/')
    time.sleep(0.3)
    print('Stresse.ru')
    print('https://stresse.ru')
    time.sleep(600)

elif choice == '3':
    print('https://check-host.net/')
    time.sleep(0.3)
    print('https://dsnchecker.org')
    time.sleep(0.3)
    print('https://www.iplocation.net')
    time.sleep(0.3)
    print('https://www.ip-tracker.org')
    time.sleep(0.3)
    print('https://https://ipinfo.io/')
    time.sleep(600)
